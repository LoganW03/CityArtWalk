package com.bignerdranch.android.cityartwalk

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

private const val TAG = "ArtListViewModel"

class ArtListViewModel : ViewModel() {

    val arts = mutableListOf<Art>()

    init {
        Log.d(TAG, "init starting")
        viewModelScope.launch {
            Log.d(TAG, "coroutine launched")
            arts += loadArts()
            Log.d(TAG, "Loading art finished")
        }
    }

    suspend fun loadArts(): List<Art> {
        val randomNumbers = (1..999).shuffled().take(100)
        val result = mutableListOf<Art>()
        delay(5000)
        for (i in 0 until 100) {
            val art = Art(
                id = UUID.randomUUID(),
                title = "Art #$i",
                date = Date(),
                address = "${randomNumbers[i]} Placeholder St"
            )

            arts += art
            result += art
        }
        return result
    }
}

//class ArtListViewMode(artId: UUID) : ViewModel() {

//    private val artRepository = ArtRepository.get()

//    private val _art: MutableStateFlow<Art?> =
//        MutableStateFlow(null)

//    val art: StateFlow<Art?> = _art.asStateFlow()

//    init {
//        viewModelScope.launch {
//            artRepository.getArt(artId).collect{
//                _art.value = it
//            }
//        }
//    }

//    fun updateArt(onUpdate: (Art) -> Art) {
//        _art.update {oldArt ->
//            oldArt?.let {onUpdate(it) }
//        }
//    }

//    suspend fun loadArts(): List<Art> {
//        return ArtRepository.getArts()
//        }
//}