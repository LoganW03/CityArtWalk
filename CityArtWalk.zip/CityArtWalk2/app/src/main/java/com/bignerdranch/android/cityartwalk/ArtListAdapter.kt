package com.bignerdranch.android.cityartwalk

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bignerdranch.android.cityartwalk.databinding.ListItemArtBinding

class ArtHolder(
    private val binding: ListItemArtBinding,
    private val onArtClicked: () -> Unit
) : RecyclerView.ViewHolder(binding.root) {
    fun bind(art: Art) {
        binding.artTitle.text = art.title
        binding.artDate.text = art.date.toString()
        binding.artAddress.text = art.address

        binding.root.setOnClickListener{
            onArtClicked()
        }
    }
}

class ArtListAdapter (
    private val arts: List<Art>,
    private val onArtClicked: () -> Unit
) : RecyclerView.Adapter<ArtHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ArtHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ListItemArtBinding.inflate(inflater, parent, false)
        return ArtHolder(binding, onArtClicked)
    }

    override fun onBindViewHolder(holder: ArtHolder, position: Int) {
        val art = arts[position]
        holder.bind(art)
    }

    override fun getItemCount() = arts.size
}