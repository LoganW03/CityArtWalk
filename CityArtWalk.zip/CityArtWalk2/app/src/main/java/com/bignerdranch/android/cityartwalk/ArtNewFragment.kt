package com.bignerdranch.android.cityartwalk

import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.Manifest
import android.net.Uri
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.bignerdranch.android.cityartwalk.databinding.FragmentArtNewBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.Calendar
import java.util.Date
import java.util.UUID

class ArtNewFragment : Fragment() {

    private var _binding: FragmentArtNewBinding? = null
    private val binding get() = checkNotNull(_binding)

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var newArt: Art
    private var saved: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        newArt = Art(
            id = UUID.randomUUID(),
            title = "",
            date = Date(),
            address = ""
        )
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentArtNewBinding.inflate(inflater, container, false)
        return binding.root
    }

    private fun saveArtRecord() {
        // Update the Art record with data from the UI
        newArt = newArt.copy(
            title = binding.artTitle.text.toString(),
            address = binding.artAddress.text.toString()
        )

        // Enable the Share button once the art is saved
        saved = true
        binding.shareButton.isEnabled = true
    }
    private fun shareArtRecord() {
        val artSummary = "Art Title: ${newArt.title}\n" +
                "Address: ${newArt.address}\n" +
                "Date: ${newArt.date}"

        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, artSummary)
            type = "text/plain"
        }

        val chooser = Intent.createChooser(shareIntent, "Share Art Record")
        startActivity(chooser)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initially set the date to the current date
        binding.artDateButton.text = newArt.date.toString()
        // Initially disable the "Show Location on Map" button

        binding.showMapButton.isEnabled = false
        // Handle Save button click

        binding.saveButton.setOnClickListener {
            newArt = newArt.copy(
                title = binding.artTitle.text.toString(),
                address = binding.artAddress.text.toString()
            )
            // Logic to save the new art item, e.g., updating the ViewModel or database
        }

        // Initially disable the Share button until Save is pressed
        binding.shareButton.isEnabled = false

        // Handle Save button click
        binding.saveButton.setOnClickListener {
            saveArtRecord()
        }

        // Handle Share button click
        binding.shareButton.setOnClickListener {
            shareArtRecord()
        }

        // Handle Date Picker button click
        binding.artDateButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)
            // Show the DatePickerDialog
            val datePickerDialog = DatePickerDialog(
                requireContext(),
                { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                    val selectedDate = Calendar.getInstance()
                    selectedDate.set(selectedYear, selectedMonth, selectedDayOfMonth)
                    newArt = newArt.copy(date = selectedDate.time)
                    // Update the date button text with the selected date
                    binding.artDateButton.text = newArt.date.toString()
                },
                year, month, dayOfMonth
            )
            datePickerDialog.show()
        }

        // Handle GPS button click
        binding.gpsButton.setOnClickListener {
            getLastKnownLocation()
        }

        // Handle Show Map button click
        binding.showMapButton.setOnClickListener {
            showLocationOnMap()
        }

        binding.shareButton.isEnabled = false
        binding.shareButton.setOnClickListener {
            shareArtRecord()
        }
    }

    private fun getLastKnownLocation() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude
                    binding.gpsButton.text = "Location: $latitude, $longitude"
                    newArt = newArt.copy(address = "Latitude: $latitude, Longitude: $longitude")

                    // Enable the "Show Location on Map" button after getting the GPS location
                    binding.showMapButton.isEnabled = true
                } else {
                    binding.gpsButton.text = "Location not found"
                }
            }
        } else {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    private fun showLocationOnMap() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude
                    // Launch Google Maps with the GPS coordinates
                    val gmmIntentUri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude")
                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                    mapIntent.setPackage("com.google.android.apps.maps")
                    startActivity(mapIntent)
                } else {
                    binding.gpsButton.text = "Location not found"
                }
            }
        } else {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}



