package com.bignerdranch.android.cityartwalk

import HelpFragment
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageButton
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.bignerdranch.android.cityartwalk.databinding.FragmentArtListBinding
import kotlinx.coroutines.launch

private const val TAG = "ArtListFragment"

class ArtListFragment : Fragment() {

    private var _binding: FragmentArtListBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "CAnnot access binding because it is null. Is the view visible?"
        }

    private val ArtListViewModel: ArtListViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "Total art: ${ArtListViewModel.arts.size}")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentArtListBinding.inflate(inflater, container, false)
        binding.artRecyclerView.layoutManager = LinearLayoutManager(context)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize buttons
        val newButton: AppCompatImageButton = view.findViewById(R.id.new_button)
        newButton.setOnClickListener {
            // Navigate to ArtNewFragment
            findNavController().navigate(R.id.add_new_art)
        }

        val helpButton: AppCompatImageButton = view.findViewById(R.id.help_button)
        helpButton.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, HelpFragment())
                .addToBackStack(null)
                .commit()
        }




        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                val arts = ArtListViewModel.loadArts()
                binding.artRecyclerView.adapter = ArtListAdapter(arts) {
                    findNavController().navigate(
                        R.id.show_art_detail
                    )
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
