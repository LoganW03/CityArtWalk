package com.bignerdranch.android.cityartwalk

import java.util.Date
import java.util.UUID


data class Art(
    val id: UUID,
    val title: String,
    val date: Date,
    val address: String,
)
